from django.apps import AppConfig


class ProfessorsapiConfig(AppConfig):
    name = 'professorsapi'
