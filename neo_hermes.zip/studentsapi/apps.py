from django.apps import AppConfig


class StudentsapiConfig(AppConfig):
    name = 'studentsapi'
