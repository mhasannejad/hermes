from django.shortcuts import render
from rest_framework.decorators import api_view
# Create your views here.
from rest_framework.response import Response
from .models import *
from studentsapi.serializers import *


@api_view(['POST'])
def login(request):
    if len(User.objects.filter(id_code=request.POST['id_code'])) > 0:
        user = User.objects.filter(id_code=request.POST['id_code']).first()
        sr = UserSerializerSelf(user)
        return Response(sr.data)
    else:
        user = User.objects.create(
            id_code=request.POST['id_code'],
            name=request.POST['name'],
        )
        sr = UserSerializerSelf(user)
        return Response(sr.data)
